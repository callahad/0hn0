0h n0
=====

It's [0h h1](http://0hh1.com)'s companion! By [Q42](http://q42.com).
It was written by [Martin Kool](http://twitter.com/mrtnkl).

Play it here:

Online at [0hn0.com](http://0hn0.com)

[iOS](https://itunes.apple.com/us/app/0h-n0/id957191082?mt=8)

[Android](https://play.google.com/store/apps/details?id=com.q42.ohno)